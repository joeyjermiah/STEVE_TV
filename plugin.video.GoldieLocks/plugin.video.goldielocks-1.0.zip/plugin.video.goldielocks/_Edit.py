import xbmcaddon

MainBase = 'https://pastebin.com/raw/cYRrNDQ1'
addon = xbmcaddon.Addon('plugin.video.GoldieLocks')